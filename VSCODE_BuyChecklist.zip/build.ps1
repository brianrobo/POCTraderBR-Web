# Builds dist\BuyChecklist.exe (single file, no console window).
# Usage: powershell -ExecutionPolicy Bypass -File build.ps1
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (-not (Test-Path .venv)) {
    py -3 -m venv .venv
}
.\.venv\Scripts\python.exe -m pip install -q -r requirements-dev.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -t .
.\.venv\Scripts\pyinstaller.exe --noconfirm --clean --onefile --windowed --name BuyChecklist main.py

Write-Host "Built: $PSScriptRoot\dist\BuyChecklist.exe"
