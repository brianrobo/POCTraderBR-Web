import tempfile
import unittest
from datetime import datetime
from pathlib import Path

from buy_checklist.rules import Answer, Verdict
from buy_checklist.storage import CheckLog, Settings


class StorageTest(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp())

    def test_settings_round_trip(self):
        path = self.dir / "settings.json"
        Settings(geometry="260x400+-1500+120", descriptions={"double_burst": "수정한 설명"}).save(path)
        loaded = Settings.load(path)
        self.assertEqual(loaded.geometry, "260x400+-1500+120")
        self.assertEqual(loaded.descriptions, {"double_burst": "수정한 설명"})

    def test_timeout_round_trip_and_bad_value(self):
        path = self.dir / "settings.json"
        Settings(timeout_until="2026-10-27T22:40:00").save(path)
        self.assertEqual(Settings.load(path).timeout_end(), datetime(2026, 10, 27, 22, 40))
        path.write_text('{"timeout_until": "garbage"}', encoding="utf-8")
        self.assertIsNone(Settings.load(path).timeout_end())

    def test_missing_or_corrupt_settings_fall_back_to_defaults(self):
        self.assertEqual(Settings.load(self.dir / "nope.json"), Settings())
        bad = self.dir / "bad.json"
        bad.write_text("{not json", encoding="utf-8")
        self.assertEqual(Settings.load(bad), Settings())

    def test_log_appends_records(self):
        log = CheckLog(self.dir / "log.jsonl")
        log.append(Verdict.BLOCKED, {"a": Answer.YES, "b": None})
        log.append(Verdict.REVIEW, {"a": Answer.NO})
        records = log.read_all()
        self.assertEqual([r["verdict"] for r in records], ["blocked", "review"])
        self.assertEqual(records[0]["answers"], {"a": "yes", "b": None})
        self.assertIn("time", records[0])


if __name__ == "__main__":
    unittest.main()
