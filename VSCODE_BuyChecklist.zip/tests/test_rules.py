import itertools
import unittest

from buy_checklist.rules import CHECK_ITEMS, Answer, Verdict, evaluate

Y, N = Answer.YES, Answer.NO
IDS = [item.id for item in CHECK_ITEMS]


def answers(*values):
    return dict(zip(IDS, values))


class EvaluateTest(unittest.TestCase):
    def test_starts_as_checking(self):
        self.assertIs(evaluate(answers(None, None, None, None)), Verdict.CHECKING)
        self.assertIs(evaluate({}), Verdict.CHECKING)

    def test_only_exact_pass_combination_is_green(self):
        # ① 아니오, ② 예, ③ 아니오, ④ 아니오
        self.assertIs(evaluate(answers(N, Y, N, N)), Verdict.REVIEW)
        for combo in itertools.product([Y, N], repeat=4):
            if combo != (N, Y, N, N):
                self.assertIs(evaluate(answers(*combo)), Verdict.BLOCKED, combo)

    def test_any_failure_blocks_even_when_incomplete(self):
        self.assertIs(evaluate(answers(Y, None, None, None)), Verdict.BLOCKED)
        self.assertIs(evaluate(answers(None, N, None, None)), Verdict.BLOCKED)
        self.assertIs(evaluate(answers(None, None, Y, None)), Verdict.BLOCKED)
        self.assertIs(evaluate(answers(None, None, None, Y)), Verdict.BLOCKED)

    def test_partial_passes_stay_checking(self):
        self.assertIs(evaluate(answers(N, None, None, None)), Verdict.CHECKING)
        self.assertIs(evaluate(answers(N, Y, None, None)), Verdict.CHECKING)
        self.assertIs(evaluate(answers(N, Y, N, None)), Verdict.CHECKING)
        self.assertIs(evaluate(answers(None, Y, N, N)), Verdict.CHECKING)


if __name__ == "__main__":
    unittest.main()
