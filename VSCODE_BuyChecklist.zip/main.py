"""Entry point (also the PyInstaller target)."""
from buy_checklist.storage import CheckLog, Settings, app_data_dir
from buy_checklist.ui.app import ChecklistApp


def main() -> None:
    data_dir = app_data_dir()
    settings_path = data_dir / "settings.json"
    app = ChecklistApp(Settings.load(settings_path), settings_path, CheckLog(data_dir / "check_log.jsonl"))
    app.mainloop()


if __name__ == "__main__":
    main()
