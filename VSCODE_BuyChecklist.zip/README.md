# 매수 체크 (BuyChecklist)

영웅문 HTS 옆에 항상 띄워두고, 매수 전에 3가지 조건을 반드시 확인하게 만드는 작은 Windows 체크리스트 앱.

> 익숙한 패턴이 나오면 매수 시작이 아니라 체크 시작이다.

## 실행

```powershell
py -3 main.py
```

Python 3.10+ (Tkinter 포함, python.org 설치본 기본 포함). 외부 패키지 없음, 인터넷 불필요.

## .exe 빌드

```powershell
powershell -ExecutionPolicy Bypass -File build.ps1
```

`.venv` 생성 → PyInstaller 설치 → 테스트 실행 → `dist\BuyChecklist.exe` (단일 파일, 콘솔 창 없음) 생성.

## 판정 규칙

| 항목 | 통과 조건 |
|---|---|
| ① 두 번 터졌냐? | 아니오 |
| ② 시가 지키고 작은 파동 만들었냐? | 예 |
| ③ 돌파 전에 터졌냐? | 아니오 |

- 하나라도 실패 → **매수 금지** (빨강). 미선택 항목이 남아 있어도 즉시 빨강.
- 실패 없이 미선택 항목이 남아 있음 → **체크 중** (회색)
- 3개 모두 선택 + 모두 통과 → **매수 검토 가능** (초록)

선택한 답 버튼도 통과면 초록, 실패면 빨강으로 표시된다. 선택된 버튼을 다시 누르면 선택이 해제된다.
항목 제목에 마우스를 올리면 상세 설명이 툴팁으로 보인다.

## 저장 위치

`%APPDATA%\BuyChecklist\`

- `settings.json` — 마지막 창 위치/크기, 사용자가 수정한 상세 설명 (기본값과 다른 것만 저장)
- `check_log.jsonl` — 판정이 빨강/초록으로 바뀔 때마다 한 줄씩 기록 (`time`, `verdict`, `answers`, `symbol`, `note`)

저장된 창 위치가 현재 모니터 범위를 벗어나면(모니터 분리 등) 기본 위치로 연다.

## 구조

```
main.py                         진입점 (PyInstaller 대상)
buy_checklist/
  rules.py                      체크 항목 정의 + 판정 로직 (UI/파일 의존 없음)
  storage.py                    설정 저장, 체크 기록(JSONL)
  ui/app.py                     메인 창
  ui/settings_dialog.py         상세 설명 확인·수정 창
  ui/tooltip.py, ui/theme.py    툴팁, 색/폰트
tests/                          판정 로직·저장 테스트 (python -m unittest)
```

확장 포인트:
- 종목명 입력: `CheckLog.append(..., symbol=...)` 필드가 이미 있음. 메인 창에 입력칸만 추가하면 됨.
- 매매 복기: `CheckLog.read_all()`로 기록을 읽어 별도 화면에서 사용.
- HTS 연동: `rules.evaluate()`는 UI와 분리되어 있어 다른 모듈에서 그대로 호출 가능.
