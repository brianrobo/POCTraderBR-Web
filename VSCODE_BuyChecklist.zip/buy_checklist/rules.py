"""Checklist items and the verdict logic.

This module has no UI or file I/O so the rules can be tested and reused
(e.g. by a future trade-review screen or HTS integration) on their own.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Mapping, Optional, Sequence


class Answer(str, Enum):
    YES = "yes"
    NO = "no"


class Verdict(str, Enum):
    CHECKING = "checking"  # gray: some answers missing, nothing failed yet
    BLOCKED = "blocked"    # red: at least one answer fails its rule
    REVIEW = "review"      # green: all three answered and all pass


@dataclass(frozen=True)
class CheckItem:
    id: str
    title: str
    pass_answer: Answer
    default_description: str
    fail_message: str = ""  # shown under the item while its answer fails
    fail_timeout_minutes: int = 0  # failing this item locks all checks for this long


CHECK_ITEMS: tuple[CheckItem, ...] = (
    CheckItem(
        id="double_burst",
        title="① 두 번 터졌냐?",
        pass_answer=Answer.NO,
        default_description=(
            "큰 파동 이후 고점 돌파 과정에서 1분봉 대량거래를 동반한 돌파 시도가 "
            "2회 이상 발생했는지 확인.\n"
            "두 번 이상 터졌다면 물량 넘김/배분 가능성을 의심하여 제외."
        ),
    ),
    CheckItem(
        id="held_open_small_wave",
        title="② 시가 지키고 작은 파동 만들었냐?",
        pass_answer=Answer.YES,
        default_description=(
            "첫 큰 상승 파동 이후 조정 과정에서 큰 파동의 시가를 지키고, "
            "그 위에서 작은 상승 파동을 형성했는지 확인."
        ),
    ),
    CheckItem(
        id="burst_before_breakout",
        title="③ 돌파 전에 터졌냐?",
        pass_answer=Answer.NO,
        default_description=(
            "작은 파동의 고점을 돌파하기 전에 1분봉 거래량이 연속적으로 과도하게 "
            "터졌는지 확인.\n"
            "이미 거래량이 과열됐다면 가짜 돌파/배분 가능성을 보고 제외."
        ),
    ),
    CheckItem(
        id="recent_loss",
        title="④ 매매 실패했나?",
        pass_answer=Answer.NO,
        default_description=(
            "직전 매매에서 손실을 봤는지 확인.\n"
            "실패 직후에는 손실을 만회하려는 뇌동매매가 나오기 쉬우므로 매수하지 않는다."
        ),
        fail_message="실패 시 복구하려고 뇌동매매 금지",
        fail_timeout_minutes=30,
    ),
)

Answers = Mapping[str, Optional[Answer]]


def is_pass(item: CheckItem, answer: Optional[Answer]) -> Optional[bool]:
    """True/False for an answered item, None while unanswered."""
    if answer is None:
        return None
    return answer == item.pass_answer


def evaluate(answers: Answers, items: Sequence[CheckItem] = CHECK_ITEMS) -> Verdict:
    results = [is_pass(item, answers.get(item.id)) for item in items]
    if any(r is False for r in results):
        return Verdict.BLOCKED
    if all(r is True for r in results):
        return Verdict.REVIEW
    return Verdict.CHECKING
