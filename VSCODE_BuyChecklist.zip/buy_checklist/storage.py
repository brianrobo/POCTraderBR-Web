"""Local persistence: user settings (window geometry, edited descriptions)
and an append-only log of check results.

Everything lives under %APPDATA%\\BuyChecklist so it survives rebuilding or
moving the .exe and needs no write access to the install folder.
"""
from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Mapping, Optional

from .rules import Answer, Verdict

APP_NAME = "BuyChecklist"


def app_data_dir() -> Path:
    base = os.environ.get("APPDATA")
    path = Path(base) / APP_NAME if base else Path.home() / f".{APP_NAME.lower()}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _write_json_atomic(path: Path, data: object) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path)


@dataclass
class Settings:
    geometry: Optional[str] = None  # Tk geometry string "WxH+X+Y"
    descriptions: dict[str, str] = field(default_factory=dict)  # item id -> edited text
    # End of the current 작전 타임 (ISO time). Saved so restarting the app
    # does not cut a timeout short.
    timeout_until: Optional[str] = None

    @classmethod
    def load(cls, path: Path) -> "Settings":
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return cls()
        if not isinstance(raw, dict):
            return cls()
        geometry = raw.get("geometry")
        descriptions = raw.get("descriptions")
        return cls(
            geometry=geometry if isinstance(geometry, str) else None,
            descriptions={k: v for k, v in descriptions.items() if isinstance(v, str)}
            if isinstance(descriptions, dict)
            else {},
            timeout_until=_valid_time(raw.get("timeout_until")),
        )

    def timeout_end(self) -> Optional[datetime]:
        return datetime.fromisoformat(self.timeout_until) if self.timeout_until else None

    def save(self, path: Path) -> None:
        _write_json_atomic(path, asdict(self))


def _valid_time(value: object) -> Optional[str]:
    if not isinstance(value, str):
        return None
    try:
        datetime.fromisoformat(value)
    except ValueError:
        return None
    return value


class CheckLog:
    """One JSON object per line, so records can be appended cheaply and
    later read by a review/statistics feature."""

    def __init__(self, path: Path) -> None:
        self.path = path

    def append(
        self,
        verdict: Verdict,
        answers: Mapping[str, Optional[Answer]],
        symbol: Optional[str] = None,
        note: Optional[str] = None,
    ) -> None:
        record = {
            "time": datetime.now().isoformat(timespec="seconds"),
            "verdict": verdict.value,
            "answers": {k: (v.value if v else None) for k, v in answers.items()},
            "symbol": symbol,
            "note": note,
        }
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def read_all(self) -> list[dict]:
        if not self.path.exists():
            return []
        records = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            try:
                records.append(json.loads(line))
            except ValueError:
                continue
        return records
