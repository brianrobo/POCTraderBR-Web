"""Main always-on-top checklist window."""
from __future__ import annotations

import re
import tkinter as tk
from datetime import datetime, timedelta
from tkinter import messagebox
from typing import Optional

from ..rules import CHECK_ITEMS, Answer, CheckItem, Verdict, evaluate, is_pass
from ..storage import CheckLog, Settings
from .settings_dialog import SettingsDialog
from .theme import (
    ANSWER_FAIL_BG,
    ANSWER_PASS_BG,
    ANSWER_SELECTED_FG,
    BG,
    BUTTON_IDLE_BG,
    CLOCK_BG,
    CLOCK_FG,
    FONT,
    FONT_BOLD,
    FONT_CLOCK,
    FONT_MOTTO,
    FONT_VERDICT,
    MOTTO_BG,
    MOTTO_FG,
    VERDICT_STYLE,
)
from .tooltip import Tooltip

MOTTO = "익숙한 패턴이 나오면\n매수 시작이 아니라 체크 시작이다."
ANSWER_LABELS = ((Answer.YES, "예"), (Answer.NO, "아니오"))


class ChecklistRow:
    """One question with its 예/아니오 buttons. Clicking the selected answer
    again clears it, so a mis-click can be undone without a full reset."""

    def __init__(self, master: tk.Misc, item: CheckItem, description: str, on_change) -> None:
        self.item = item
        self.answer: Optional[Answer] = None
        self._on_change = on_change

        self.frame = tk.Frame(master, bg=BG)
        title = tk.Label(self.frame, text=item.title, font=FONT_BOLD, bg=BG, anchor="w", cursor="question_arrow")
        title.pack(fill="x")
        self.tooltip = Tooltip(title, description)

        buttons = tk.Frame(self.frame, bg=BG)
        buttons.pack(fill="x", pady=(2, 0))
        self._buttons: dict[Answer, tk.Button] = {}
        for answer, label in ANSWER_LABELS:
            btn = tk.Button(
                buttons,
                text=label,
                font=FONT,
                relief="groove",
                bd=1,
                command=lambda a=answer: self._click(a),
            )
            btn.pack(side="left", fill="x", expand=True, padx=(0, 4) if answer is Answer.YES else 0)
            self._buttons[answer] = btn
        self._warning = tk.Label(self.frame, text=item.fail_message, font=FONT_BOLD, bg=BG, fg=ANSWER_FAIL_BG, anchor="w")
        self._refresh()

    def _click(self, answer: Answer) -> None:
        self.answer = None if self.answer is answer else answer
        self._refresh()
        self._on_change(self)

    def clear(self) -> None:
        self.answer = None
        self._refresh()

    def set_description(self, text: str) -> None:
        self.tooltip.text = text

    def set_enabled(self, enabled: bool) -> None:
        for btn in self._buttons.values():
            btn.configure(state="normal" if enabled else "disabled")

    def _refresh(self) -> None:
        passed = is_pass(self.item, self.answer)
        for answer, btn in self._buttons.items():
            if answer is self.answer:
                bg = ANSWER_PASS_BG if passed else ANSWER_FAIL_BG
                btn.configure(bg=bg, activebackground=bg, fg=ANSWER_SELECTED_FG, relief="sunken")
            else:
                btn.configure(bg=BUTTON_IDLE_BG, activebackground=BUTTON_IDLE_BG, fg="black", relief="groove")
        if passed is False and self.item.fail_message:
            self._warning.pack(fill="x", pady=(2, 0))
        else:
            self._warning.pack_forget()


class ChecklistApp(tk.Tk):
    DEFAULT_GEOMETRY = "260x480"
    MIN_SIZE = (220, 450)
    # See-through while idle so the chart behind stays visible; solid while
    # the mouse is over the window so the checklist is easy to read.
    IDLE_ALPHA = 0.75

    def __init__(self, settings: Settings, settings_path, check_log: CheckLog) -> None:
        super().__init__()
        self.settings = settings
        self.settings_path = settings_path
        self.check_log = check_log
        self._last_verdict = Verdict.CHECKING
        # The checklist is good for the day it was opened on; once midnight
        # passes it locks into a blinking 매수 금지 until the user unlocks it
        # (the 초기화 button turns into 잠금 해제) or restarts the app.
        self._session_date = datetime.now().date()
        self._locked = False
        self._blink_on = True
        self._timeout_until = settings.timeout_end()

        self.title("매수 체크")
        self.configure(bg=BG)
        self.attributes("-topmost", True)
        self.minsize(*self.MIN_SIZE)
        self.geometry(self._initial_geometry())
        self.protocol("WM_DELETE_WINDOW", self.quit_app)
        self.attributes("-alpha", self.IDLE_ALPHA)
        self.bind("<Enter>", lambda _e: self.attributes("-alpha", 1.0))
        self.bind("<Leave>", self._on_leave)

        self._build()
        self._update_verdict()
        self._tick()
        self._blink()

    # ---- layout -------------------------------------------------------
    def _build(self) -> None:
        self.clock_label = tk.Label(self, font=FONT_CLOCK, bg=CLOCK_BG, fg=CLOCK_FG, pady=4)
        self.clock_label.pack(fill="x")

        tk.Label(
            self, text=MOTTO, font=FONT_MOTTO, bg=MOTTO_BG, fg=MOTTO_FG, justify="center", pady=6, wraplength=240
        ).pack(fill="x")

        # Bottom widgets are packed before the body so that, when the window
        # is made small, the questions shrink first and the verdict stays visible.
        self.verdict_label = tk.Label(self, font=FONT_VERDICT, fg="white", pady=14)
        self.verdict_label.pack(fill="x", side="bottom", pady=(8, 0))

        buttons = tk.Frame(self, bg=BG, padx=8)
        buttons.pack(fill="x", side="bottom")
        self.reset_button = tk.Button(buttons, text="초기화", font=FONT, command=self.reset)
        self.reset_button.pack(side="left", fill="x", expand=True, padx=2)
        for text, command in (("설정", self.open_settings), ("종료", self.quit_app)):
            tk.Button(buttons, text=text, font=FONT, command=command).pack(side="left", fill="x", expand=True, padx=2)

        body = tk.Frame(self, bg=BG, padx=8, pady=6)
        body.pack(fill="both", expand=True)
        self.rows: list[ChecklistRow] = []
        for item in CHECK_ITEMS:
            row = ChecklistRow(body, item, self._description_for(item), self._on_answer)
            row.frame.pack(fill="x", pady=(0, 8))
            self.rows.append(row)

    def _description_for(self, item: CheckItem) -> str:
        return self.settings.descriptions.get(item.id) or item.default_description

    # ---- behaviour ----------------------------------------------------
    def answers(self) -> dict[str, Optional[Answer]]:
        return {row.item.id: row.answer for row in self.rows}

    def _tick(self) -> None:
        now = datetime.now()
        self.clock_label.configure(text=now.strftime("%Y-%m-%d %H:%M:%S"))
        # Compare dates rather than watching for 00:00:00 so a tick missed
        # during sleep/hibernate still locks the checklist on wake.
        if not self._locked and now.date() != self._session_date:
            self._locked = True
        if self._timeout_until and now >= self._timeout_until:
            self._end_timeout()
        self._apply_lock()
        self._update_verdict()
        self.after(1000 - now.microsecond // 1000, self._tick)

    def _on_leave(self, _event) -> None:
        # <Leave> also fires when moving between child widgets; only fade
        # once the pointer is really outside this window.
        under = self.winfo_containing(*self.winfo_pointerxy())
        if under is None or under.winfo_toplevel() is not self:
            self.attributes("-alpha", self.IDLE_ALPHA)

    def _is_locked(self) -> bool:
        return self._locked or self._timeout_until is not None

    def _apply_lock(self) -> None:
        for row in self.rows:
            row.set_enabled(not self._is_locked())
        self.reset_button.configure(text="잠금 해제" if self._locked else "초기화")

    def _blink(self) -> None:
        self._blink_on = not self._blink_on if self._locked else True
        if self._locked:
            self._update_verdict()
        self.after(500, self._blink)

    def _unlock_midnight(self) -> None:
        if not messagebox.askokcancel(
            "잠금 해제", "자정이 지나 매수 금지 상태입니다.\n잠금을 해제하고 오늘 체크를 새로 시작할까요?", parent=self
        ):
            return
        self._locked = False
        self._session_date = datetime.now().date()
        for row in self.rows:
            row.clear()
        self._last_verdict = Verdict.CHECKING
        self._apply_lock()
        self._update_verdict()

    def _on_answer(self, row: ChecklistRow) -> None:
        minutes = row.item.fail_timeout_minutes
        if minutes and is_pass(row.item, row.answer) is False:
            if messagebox.askokcancel(
                "작전 타임",
                f"{row.item.fail_message}\n\n즉시 거래를 중단하고 {minutes}분간 작전 타임을 시작합니다.\n"
                f"시작하면 {minutes}분 동안 체크할 수 없습니다.",
                icon="warning",
                parent=self,
            ):
                self._start_timeout(minutes)
            else:
                row.clear()  # mis-click: undo the answer instead of locking
        self._update_verdict()

    def _start_timeout(self, minutes: int) -> None:
        self._timeout_until = datetime.now().replace(microsecond=0) + timedelta(minutes=minutes)
        self.settings.timeout_until = self._timeout_until.isoformat()
        self._persist()
        try:
            self.check_log.append(Verdict.BLOCKED, self.answers(), note=f"작전 타임 {minutes}분")
        except OSError:
            pass
        self._last_verdict = Verdict.BLOCKED
        self._apply_lock()

    def _end_timeout(self) -> None:
        self._timeout_until = None
        self.settings.timeout_until = None
        self._persist()
        for row in self.rows:
            row.clear()  # start the next check from scratch
        self._last_verdict = Verdict.CHECKING

    def _update_verdict(self) -> None:
        if self._locked:
            text, color = VERDICT_STYLE[Verdict.BLOCKED]
            if self._blink_on:
                self.verdict_label.configure(text=text, bg=color, fg="white")
            else:
                self.verdict_label.configure(text=text, bg=BG, fg=color)
            return
        if self._timeout_until:
            left = max(int((self._timeout_until - datetime.now()).total_seconds()), 0)
            self.verdict_label.configure(
                text=f"작전 타임 {left // 60:02d}:{left % 60:02d}", bg=VERDICT_STYLE[Verdict.BLOCKED][1], fg="white"
            )
            return
        answers = self.answers()
        verdict = evaluate(answers)
        text, color = VERDICT_STYLE[verdict]
        self.verdict_label.configure(text=text, bg=color, fg="white")

        # Record each time a check reaches a decision (red or green), so the
        # log shows what was decided and when.
        if verdict is not self._last_verdict and verdict is not Verdict.CHECKING:
            try:
                self.check_log.append(verdict, answers)
            except OSError:
                pass  # logging must never get in the way of the checklist
        self._last_verdict = verdict

    def reset(self) -> None:
        if self._locked:
            self._unlock_midnight()
            return
        if self._is_locked():
            return
        for row in self.rows:
            row.clear()
        self._update_verdict()

    def open_settings(self) -> None:
        SettingsDialog(self, CHECK_ITEMS, {i.id: self._description_for(i) for i in CHECK_ITEMS}, self._save_descriptions)

    def _save_descriptions(self, descriptions: dict[str, str]) -> None:
        # Store only text that differs from the default, so improving a
        # default in a later version still reaches users who never edited it.
        self.settings.descriptions = {
            item.id: descriptions[item.id]
            for item in CHECK_ITEMS
            if descriptions.get(item.id) and descriptions[item.id] != item.default_description
        }
        for row in self.rows:
            row.set_description(self._description_for(row.item))
        self._persist()

    def quit_app(self) -> None:
        self.settings.geometry = self.geometry()
        self._persist()
        self.destroy()

    def _persist(self) -> None:
        try:
            self.settings.save(self.settings_path)
        except OSError:
            pass

    # ---- window placement ---------------------------------------------
    def _initial_geometry(self) -> str:
        saved = self.settings.geometry
        if saved and self._is_on_screen(saved):
            return saved
        return self.DEFAULT_GEOMETRY

    def _is_on_screen(self, geometry: str) -> bool:
        """Reject a saved position that is now off every monitor (e.g. a
        second monitor was unplugged), which would leave the window unreachable."""
        # Tk's geometry() always reports "WxH+X+Y", with "+-N" for negative
        # coordinates on a monitor left of/above the primary one.
        m = re.fullmatch(r"(\d+)x(\d+)\+(-?\d+)\+(-?\d+)", geometry)
        if not m:
            return False
        w, h, x, y = (int(g) for g in m.groups())
        left, top, width, height = _virtual_screen(self)
        margin = 40  # at least this much of the window must be visible
        return (
            w >= self.MIN_SIZE[0]
            and h >= self.MIN_SIZE[1]
            and x + w - margin > left
            and x + margin < left + width
            and y >= top - 10
            and y + margin < top + height
        )


def _virtual_screen(root: tk.Misc) -> tuple[int, int, int, int]:
    """Bounding box of all monitors on Windows; primary screen elsewhere."""
    try:
        import ctypes

        metrics = ctypes.windll.user32.GetSystemMetrics
        return metrics(76), metrics(77), metrics(78), metrics(79)  # SM_X/Y/CX/CYVIRTUALSCREEN
    except (AttributeError, OSError):
        return 0, 0, root.winfo_screenwidth(), root.winfo_screenheight()
