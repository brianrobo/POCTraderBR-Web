from ..rules import Verdict

FONT_FAMILY = "Malgun Gothic"
FONT = (FONT_FAMILY, 10)
FONT_BOLD = (FONT_FAMILY, 10, "bold")
FONT_MOTTO = (FONT_FAMILY, 10, "bold")
FONT_VERDICT = (FONT_FAMILY, 18, "bold")
FONT_CLOCK = (FONT_FAMILY, 11, "bold")

BG = "#f4f4f4"
CLOCK_BG = "#2b2b2b"
CLOCK_FG = "#ffffff"
MOTTO_BG = "#fff4cc"
MOTTO_FG = "#5a4500"

BUTTON_IDLE_BG = "#ffffff"
ANSWER_PASS_BG = "#2e9d4f"   # selected answer that satisfies the rule
ANSWER_FAIL_BG = "#d93636"   # selected answer that breaks the rule
ANSWER_SELECTED_FG = "#ffffff"

VERDICT_STYLE = {
    Verdict.CHECKING: ("체크 중", "#8a8a8a"),
    Verdict.BLOCKED: ("매수 금지", "#d93636"),
    Verdict.REVIEW: ("매수 검토 가능", "#2e9d4f"),
}
