"""Dialog for viewing and editing each item's detailed description."""
from __future__ import annotations

import tkinter as tk
from typing import Callable, Mapping, Sequence

from ..rules import CheckItem
from .theme import BG, FONT, FONT_BOLD


class SettingsDialog(tk.Toplevel):
    def __init__(
        self,
        master: tk.Misc,
        items: Sequence[CheckItem],
        descriptions: Mapping[str, str],
        on_save: Callable[[dict[str, str]], None],
    ) -> None:
        super().__init__(master)
        self.title("설정 - 체크 항목 설명")
        self.configure(bg=BG, padx=10, pady=10)
        self.transient(master)
        self.attributes("-topmost", True)  # must stay above the always-on-top main window
        self.resizable(True, True)

        self._items = items
        self._on_save = on_save
        self._texts: dict[str, tk.Text] = {}

        for item in items:
            tk.Label(self, text=item.title, font=FONT_BOLD, bg=BG, anchor="w").pack(fill="x")
            pass_text = "예" if item.pass_answer.value == "yes" else "아니오"
            tk.Label(self, text=f"통과 조건: {pass_text}", font=FONT, bg=BG, fg="#555", anchor="w").pack(fill="x")
            text = tk.Text(self, width=44, height=4, wrap="word", font=FONT, undo=True)
            text.insert("1.0", descriptions.get(item.id, item.default_description))
            text.pack(fill="both", expand=True, pady=(2, 10))
            self._texts[item.id] = text

        buttons = tk.Frame(self, bg=BG)
        buttons.pack(fill="x")
        tk.Button(buttons, text="기본값 복원", font=FONT, command=self._restore_defaults).pack(side="left")
        tk.Button(buttons, text="취소", font=FONT, width=6, command=self.destroy).pack(side="right")
        tk.Button(buttons, text="저장", font=FONT, width=6, command=self._save).pack(side="right", padx=(0, 6))

        self.bind("<Escape>", lambda _e: self.destroy())
        self.grab_set()
        self.focus_set()

    def _restore_defaults(self) -> None:
        for item in self._items:
            text = self._texts[item.id]
            text.delete("1.0", "end")
            text.insert("1.0", item.default_description)

    def _save(self) -> None:
        self._on_save({item_id: text.get("1.0", "end-1c").strip() for item_id, text in self._texts.items()})
        self.destroy()
